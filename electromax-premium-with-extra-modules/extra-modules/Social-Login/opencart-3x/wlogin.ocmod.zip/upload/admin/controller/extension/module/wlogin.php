<?php
class ControllerExtensionModuleWlogin extends Controller {
	private $error = array();

	public function index(){
		$this->load->language('extension/module/wlogin');

		$this->document->setTitle($this->language->get('heading_title1'));

		$this->load->model('setting/setting');
		
		$this->load->model('tool/image');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('module_wlogin', $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true));
		}

		$data['heading_title'] = $this->language->get('heading_title1');

		$data['text_edit'] = $this->language->get('text_edit');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');

		$data['entry_limage'] = $this->language->get('entry_limage');
		$data['entry_gimage'] = $this->language->get('entry_gimage');
		$data['entry_fimage'] = $this->language->get('entry_fimage');
		$data['entry_status'] = $this->language->get('entry_status');
		$data['entry_customergroup'] = $this->language->get('entry_customergroup');
		
		
		$data['entry_title'] = $this->language->get('entry_title');
		$data['entry_fappid'] = $this->language->get('entry_fappid');
		$data['entry_fappappsecret'] = $this->language->get('entry_fappappsecret');
		$data['entry_fcallbackurl'] = $this->language->get('entry_fcallbackurl');
		
		$data['entry_gappid'] = $this->language->get('entry_gappid');
		$data['entry_gappappsecret'] = $this->language->get('entry_gappappsecret');
		$data['entry_gcallbackurl'] = $this->language->get('entry_gcallbackurl');
		
		$data['entry_lappid'] = $this->language->get('entry_lappid');
		$data['entry_lappappsecret'] = $this->language->get('entry_lappappsecret');
		$data['entry_lcallbackurl'] = $this->language->get('entry_lcallbackurl');
		
		
		$data['entry_tappid'] = $this->language->get('entry_tappid');
		$data['entry_tappappsecret'] = $this->language->get('entry_tappappsecret');
		$data['entry_tcallbackurl'] = $this->language->get('entry_tcallbackurl');
		$data['entry_timage'] = $this->language->get('entry_timage');

		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');
		
		//tab
		$data['tab_facebook'] = $this->language->get('tab_facebook');
		$data['tab_google'] = $this->language->get('tab_google');
		$data['tab_linkedin'] = $this->language->get('tab_linkedin');
		$data['tab_twitter'] = $this->language->get('tab_twitter');
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		
		
		$this->load->model('extension/wlogins');
		$data['customergroups'] = $this->model_extension_wlogins->getCustomerGroups(array());
		
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/module/wlogin', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['action'] = $this->url->link('extension/module/wlogin', 'user_token=' . $this->session->data['user_token'], true);

		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true);
		
		$data['placeholder'] = $this->model_tool_image->resize('no_image.png', 100, 100);

		if (isset($this->request->post['module_wlogin_status'])) {
			$data['module_wlogin_status'] = $this->request->post['module_wlogin_status'];
		} else {
			$data['module_wlogin_status'] = $this->config->get('module_wlogin_status');
		}
		
		if ($this->request->server['HTTPS']) {
			$server = HTTPS_CATALOG;
		} else {
			$server = HTTP_CATALOG;
		}
		
		//facebook Code
		if (isset($this->request->post['module_wlogin_fstatus'])) {
			$data['module_wlogin_fstatus'] = $this->request->post['module_wlogin_fstatus'];
		} else {
			$data['module_wlogin_fstatus'] = $this->config->get('module_wlogin_fstatus');
		}
		
		if (isset($this->request->post['module_wlogin_fimage'])) {
			$data['module_wlogin_fimage'] = $this->request->post['module_wlogin_fimage'];
		} else {
			$data['module_wlogin_fimage'] = $this->config->get('module_wlogin_fimage');
		}

		if (isset($this->request->post['module_wlogin_fimage']) && is_file(DIR_IMAGE . $this->request->post['module_wlogin_fimage'])) {
			$data['fimage'] = $this->model_tool_image->resize($this->request->post['module_wlogin_fimage'], 100, 100);
		} elseif ($this->config->get('module_wlogin_fimage') && is_file(DIR_IMAGE . $this->config->get('module_wlogin_fimage'))) {
			$data['fimage'] = $this->model_tool_image->resize($this->config->get('module_wlogin_fimage'), 100, 100);
		} else {
			$data['fimage'] = $this->model_tool_image->resize('no_image.png', 100, 100);
		}
		
		if (isset($this->request->post['module_wlogin_fimage'])) {
			$data['module_wlogin_fimage'] = $this->request->post['module_wlogin_fimage'];
		} else {
			$data['module_wlogin_fimage'] = $this->config->get('module_wlogin_fimage');
		}
		
		if (isset($this->request->post['module_wlogin_fappid'])) {
			$data['module_wlogin_fappid'] = $this->request->post['module_wlogin_fappid'];
		} else {
			$data['module_wlogin_fappid'] = $this->config->get('module_wlogin_fappid');
		}
		
		if (isset($this->request->post['module_wlogin_fsecretkey'])) {
			$data['module_wlogin_fsecretkey'] = $this->request->post['module_wlogin_fsecretkey'];
		} else {
			$data['module_wlogin_fsecretkey'] = $this->config->get('module_wlogin_fsecretkey');
		}
		
		$data['module_wlogin_fcallback'] = $server.'index.php?route=extension/module/wlogin/fcallback';
		// End 
		
		//Google Code
		
		if (isset($this->request->post['module_wlogin_gstatus'])) {
			$data['module_wlogin_gstatus'] = $this->request->post['module_wlogin_gstatus'];
		} else {
			$data['module_wlogin_gstatus'] = $this->config->get('module_wlogin_gstatus');
		}
		
		if (isset($this->request->post['module_wlogin_gimage'])) {
			$data['module_wlogin_gimage'] = $this->request->post['module_wlogin_gimage'];
		} else {
			$data['module_wlogin_gimage'] = $this->config->get('module_wlogin_gimage');
		}

		if (isset($this->request->post['module_wlogin_gimage']) && is_file(DIR_IMAGE . $this->request->post['module_wlogin_gimage'])) {
			$data['gimage'] = $this->model_tool_image->resize($this->request->post['module_wlogin_gimage'], 100, 100);
		} elseif ($this->config->get('module_wlogin_gimage') && is_file(DIR_IMAGE . $this->config->get('module_wlogin_gimage'))) {
			$data['gimage'] = $this->model_tool_image->resize($this->config->get('module_wlogin_gimage'), 100, 100);
		} else {
			$data['gimage'] = $this->model_tool_image->resize('no_image.png', 100, 100);
		}
		
		if (isset($this->request->post['module_wlogin_gimage'])) {
			$data['module_wlogin_gimage'] = $this->request->post['module_wlogin_gimage'];
		} else {
			$data['module_wlogin_gimage'] = $this->config->get('module_wlogin_gimage');
		}
		
		if (isset($this->request->post['module_wlogin_gappid'])) {
			$data['module_wlogin_gappid'] = $this->request->post['module_wlogin_gappid'];
		} else {
			$data['module_wlogin_gappid'] = $this->config->get('module_wlogin_gappid');
		}
		
		if (isset($this->request->post['module_wlogin_gsecretkey'])) {
			$data['module_wlogin_gsecretkey'] = $this->request->post['module_wlogin_gsecretkey'];
		} else {
			$data['module_wlogin_gsecretkey'] = $this->config->get('module_wlogin_gsecretkey');
		}
		
		$data['module_wlogin_gcallback'] = $server.'index.php?route=extension/module/wlogin/gcallback';
		
		//Linkedin Code
		
		if (isset($this->request->post['module_wlogin_lstatus'])) {
			$data['module_wlogin_lstatus'] = $this->request->post['module_wlogin_lstatus'];
		} else {
			$data['module_wlogin_lstatus'] = $this->config->get('module_wlogin_lstatus');
		}
		
		if (isset($this->request->post['module_wlogin_limage'])) {
			$data['module_wlogin_limage'] = $this->request->post['module_wlogin_limage'];
		} else {
			$data['module_wlogin_limage'] = $this->config->get('module_wlogin_limage');
		}

		if (isset($this->request->post['module_wlogin_limage']) && is_file(DIR_IMAGE . $this->request->post['module_wlogin_limage'])) {
			$data['limage'] = $this->model_tool_image->resize($this->request->post['module_wlogin_limage'], 100, 100);
		} elseif ($this->config->get('module_wlogin_limage') && is_file(DIR_IMAGE . $this->config->get('module_wlogin_limage'))) {
			$data['limage'] = $this->model_tool_image->resize($this->config->get('module_wlogin_limage'), 100, 100);
		} else {
			$data['limage'] = $this->model_tool_image->resize('no_image.png', 100, 100);
		}
		
		if (isset($this->request->post['module_wlogin_lcustomergroup'])) {
			$data['module_wlogin_lcustomergroup'] = $this->request->post['module_wlogin_lcustomergroup'];
		} else {
			$data['module_wlogin_lcustomergroup'] = $this->config->get('module_wlogin_lcustomergroup');
		}
		
		if (isset($this->request->post['module_wlogin_lappid'])) {
			$data['module_wlogin_lappid'] = $this->request->post['module_wlogin_lappid'];
		} else {
			$data['module_wlogin_lappid'] = $this->config->get('module_wlogin_lappid');
		}
		
		if (isset($this->request->post['module_wlogin_lsecretkey'])) {
			$data['module_wlogin_lsecretkey'] = $this->request->post['module_wlogin_lsecretkey'];
		} else {
			$data['module_wlogin_lsecretkey'] = $this->config->get('module_wlogin_lsecretkey');
		}
		
		$data['module_wlogin_lcallback'] = $server.'index.php?route=extension/module/wlogin/lcallback';
		
		
		//Twitter Code
		
		if (isset($this->request->post['module_wlogin_tstatus'])) {
			$data['module_wlogin_tstatus'] = $this->request->post['module_wlogin_tstatus'];
		} else {
			$data['module_wlogin_tstatus'] = $this->config->get('module_wlogin_tstatus');
		}
		
		if (isset($this->request->post['module_wlogin_timage'])) {
			$data['module_wlogin_timage'] = $this->request->post['module_wlogin_timage'];
		} else {
			$data['module_wlogin_timage'] = $this->config->get('module_wlogin_timage');
		}

		if (isset($this->request->post['module_wlogin_timage']) && is_file(DIR_IMAGE . $this->request->post['module_wlogin_timage'])) {
			$data['timage'] = $this->model_tool_image->resize($this->request->post['module_wlogin_timage'], 100, 100);
		} elseif ($this->config->get('module_wlogin_timage') && is_file(DIR_IMAGE . $this->config->get('module_wlogin_timage'))) {
			$data['timage'] = $this->model_tool_image->resize($this->config->get('module_wlogin_timage'), 100, 100);
		} else {
			$data['timage'] = $this->model_tool_image->resize('no_image.png', 100, 100);
		}
		
		if (isset($this->request->post['module_wlogin_tcustomergroup'])) {
			$data['module_wlogin_tcustomergroup'] = $this->request->post['module_wlogin_tcustomergroup'];
		} else {
			$data['module_wlogin_tcustomergroup'] = $this->config->get('module_wlogin_tcustomergroup');
		}
		
		if (isset($this->request->post['module_wlogin_tappid'])) {
			$data['module_wlogin_tappid'] = $this->request->post['module_wlogin_tappid'];
		} else {
			$data['module_wlogin_tappid'] = $this->config->get('module_wlogin_tappid');
		}
		
		if (isset($this->request->post['module_wlogin_tsecretkey'])) {
			$data['module_wlogin_tsecretkey'] = $this->request->post['module_wlogin_tsecretkey'];
		} else {
			$data['module_wlogin_tsecretkey'] = $this->config->get('module_wlogin_tsecretkey');
		}
		
		$data['module_wlogin_tcallback'] = $server.'index.php?route=extension/module/wlogin/twitter';
		
		$this->load->model('localisation/language');

		$languages = $this->model_localisation_language->getLanguages();
		
		foreach($languages as $language){
			if (isset($this->request->post['module_wlogin_title' . $language['language_id']])) {
				$data['module_wlogin_title'][$language['language_id']] = $this->request->post['module_wlogin_title' . $language['language_id']];
			} else {
				$data['module_wlogin_title'][$language['language_id']] = $this->config->get('module_wlogin_title' . $language['language_id']);
			}
		}
		
		$data['languages'] = $languages;
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		$this->response->setOutput($this->load->view('extension/module/wlogin', $data));
		
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/module/wlogin')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
}