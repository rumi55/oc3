<?php
// Heading
$_['heading_title']    = 'Canonical Links';

// Text 
$_['text_success']     = 'Success: You have saved Canonical Links!';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Canonical Links!';
?>