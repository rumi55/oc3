<?php
// Heading
$_['heading_title']       = '404s Report';


// Error
$_['error_permission']    = 'Warning: You do not have permission to modify 404s Report!';
?>