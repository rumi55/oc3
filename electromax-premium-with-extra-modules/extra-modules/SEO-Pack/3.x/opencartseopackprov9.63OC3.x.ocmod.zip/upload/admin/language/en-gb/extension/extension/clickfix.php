<?php
// Heading
$_['heading_title']          = 'Click & Fix SEO Tools';
$_['text_success']          = 'Success: You have successfully saved parameters!';

// Error 
$_['error_warning']          = 'Warning: Please check the form carefully for errors!';
$_['error_permission']       = 'Warning: You do not have permission to modify Click & Fix SEO Tools!';

?>