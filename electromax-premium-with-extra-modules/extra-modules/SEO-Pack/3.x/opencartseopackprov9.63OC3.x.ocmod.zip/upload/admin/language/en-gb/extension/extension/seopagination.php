<?php
// Heading
$_['heading_title']    = 'SEO Pagination';

// Text 
$_['text_success']     = 'Success: You have saved SEO Pagination!';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify SEO Pagination!';
?>