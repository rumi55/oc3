<?php
// Heading
$_['heading_title']       = 'Bots Report';


// Error
$_['error_permission']    = 'Warning: You do not have permission to modify Bots Report!';
?>