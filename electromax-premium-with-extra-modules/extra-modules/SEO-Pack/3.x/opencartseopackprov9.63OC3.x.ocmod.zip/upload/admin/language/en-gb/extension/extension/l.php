<?php
// Heading
$_['heading_title']    = 'About & License';

// Text 
$_['text_success']     = 'Success: You have saved your Opencart SEO Pack PRO License!';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify About & License!';
?>